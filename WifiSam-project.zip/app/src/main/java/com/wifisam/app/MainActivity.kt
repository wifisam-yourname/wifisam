package com.wifisam.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.LocationManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val wifi: WifiManager by lazy {
        applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#091F2C")
        window.navigationBarColor = Color.parseColor("#091F2C")

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            // لا نسمح بالخروج من صفحات التطبيق المحلية
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return !request.url.toString().startsWith("file:///android_asset/")
            }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        web.loadUrl("file:///android_asset/index.html")
        askLocationPermission()
    }

    private fun hasLocation(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun askLocationPermission() {
        if (!hasLocation()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasLocation()) web.evaluateJavascript("scan()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    inner class Bridge {
        @JavascriptInterface
        fun scan() {
            thread {
                val out = try {
                    doScan()
                } catch (e: Exception) {
                    err(e.message ?: "خطأ غير معروف")
                }
                web.post {
                    web.evaluateJavascript("window.onNativeScan(" + JSONObject.quote(out) + ")", null)
                }
            }
        }
    }

    private fun err(msg: String): String = JSONObject().put("error", msg).toString()

    private fun security(cap: String?): String {
        val c = (cap ?: "").uppercase()
        return when {
            c.contains("SAE") || c.contains("WPA3") -> "WPA3"
            c.contains("WPA2") || c.contains("RSN") -> "WPA2"
            c.contains("WPA") -> "WPA"
            c.contains("WEP") -> "WEP"
            c.contains("OWE") -> "OWE"
            c.contains("ESS") && !c.contains("PSK") && !c.contains("EAP") -> "مفتوحة"
            else -> ""
        }
    }

    @Suppress("DEPRECATION")
    private fun doScan(): String {
        if (!hasLocation()) {
            runOnUiThread { askLocationPermission() }
            return err("امنح التطبيق صلاحية الموقع الدقيق ثم اضغط امسح الآن")
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (Build.VERSION.SDK_INT >= 28 && !lm.isLocationEnabled) {
            return err("شغّل خدمة الموقع (GPS) من إعدادات الهاتف")
        }
        if (!wifi.isWifiEnabled) return err("شغّل الواي فاي")

        val latch = CountDownLatch(1)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { latch.countDown() }
        }
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        try {
            // قد يرفض النظام المسح المتكرر (حد أندرويد)؛ عندها نعرض آخر نتائج متاحة
            if (wifi.startScan()) latch.await(6, TimeUnit.SECONDS)
        } finally {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
        }

        val aps = JSONArray()
        for (r: ScanResult in wifi.scanResults) {
            val bw = when (r.channelWidth) {
                ScanResult.CHANNEL_WIDTH_40MHZ -> 40
                ScanResult.CHANNEL_WIDTH_80MHZ -> 80
                ScanResult.CHANNEL_WIDTH_160MHZ, ScanResult.CHANNEL_WIDTH_80MHZ_PLUS_MHZ -> 160
                else -> 20
            }
            val center = if (r.centerFreq0 > 0) r.centerFreq0 else r.frequency
            val ssid = r.SSID ?: ""
            aps.put(
                JSONObject()
                    .put("ssid", if (ssid == "<unknown ssid>") "" else ssid)
                    .put("bssid", (r.BSSID ?: "").lowercase())
                    .put("freq", r.frequency)
                    .put("center", center)
                    .put("rssi", r.level)
                    .put("bw", bw)
                    .put("sec", security(r.capabilities))
            )
        }

        var conn: JSONObject? = null
        val ci = wifi.connectionInfo
        if (ci != null && ci.networkId != -1) {
            val ip = ci.ipAddress
            conn = JSONObject()
                .put("ssid", (ci.ssid ?: "").trim('"').let { if (it == "<unknown ssid>") "" else it })
                .put("bssid", (ci.bssid ?: "").lowercase())
                .put("rssi", ci.rssi)
                .put("speed", ci.linkSpeed)
                .put("freq", ci.frequency)
                .put("ip", "${ip and 0xff}.${(ip shr 8) and 0xff}.${(ip shr 16) and 0xff}.${(ip shr 24) and 0xff}")
        }

        return JSONObject()
            .put("source", "android")
            .put("time", System.currentTimeMillis() / 1000)
            .put("aps", aps)
            .put("conn", conn ?: JSONObject.NULL)
            .toString()
    }
}
